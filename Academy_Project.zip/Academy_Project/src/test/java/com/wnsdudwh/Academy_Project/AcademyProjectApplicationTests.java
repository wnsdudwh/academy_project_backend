package com.wnsdudwh.Academy_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
